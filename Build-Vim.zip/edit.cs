﻿using System.Diagnostics;
using System.Linq;

class Edit
{
    static void Main(string[] args)
    {
        if (args.Length == 0) return;

        var check = new Process();
        check.StartInfo.CreateNoWindow = true;
        check.StartInfo.UseShellExecute = false;
        check.StartInfo.RedirectStandardOutput = true;
        check.StartInfo.FileName = "vim.exe";
        check.StartInfo.Arguments = "--noplugin --serverlist";

        check.Start();
        var result = check.StandardOutput.ReadToEnd();
        check.WaitForExit();

        Process.Start(
            result.StartsWith("VIM") ? "vim.exe" : "gvim.exe",
            (result == "" ? "" : "--remote-silent ") + string.Join(" ", args.Select(s => $"\"{s}\"")));
    }
}
